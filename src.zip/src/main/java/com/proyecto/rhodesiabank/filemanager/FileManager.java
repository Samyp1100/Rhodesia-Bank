package com.proyecto.rhodesiabank.filemanager;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

    public class FileManager {
        public static final String FILE_NAME = "usuarios.txt";

        public List<String> leerUsuarios() throws IOException {
            List<String> usuarios = new ArrayList<>();
            File file = new File(FILE_NAME);

            if (!file.exists()) {
                file.createNewFile();
                return usuarios;
            }

            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String linea;
                while ((linea = reader.readLine()) != null) {
                    usuarios.add(linea);
                }
            }
            return usuarios;
        }

        public void guardarUsuario(String userData) throws IOException {
            // Asegurarse de que el archivo existe
            File file = new File(FILE_NAME);
            if (!file.exists()) {
                file.createNewFile();
            }

            // Escribir el nuevo usuario
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
                writer.write(userData);
                writer.newLine();
                writer.flush();
            }
        }
    }