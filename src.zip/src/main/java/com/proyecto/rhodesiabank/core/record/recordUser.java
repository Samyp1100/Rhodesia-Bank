package com.proyecto.rhodesiabank.core.record;

import com.proyecto.rhodesiabank.core.Credential;
import com.proyecto.rhodesiabank.filemanager.FileManager;
import com.proyecto.rhodesiabank.filemanager.UserCacheManager;
import com.proyecto.rhodesiabank.core.User;
import java.io.*;

public class recordUser extends User {

    private final FileManager fileManager;

    public recordUser(String username, String email, String pass) {
        super(username, new Credential(), email, ""); // Primera línea debe ser super()
        getCredential().setPassword(pass);
        this.fileManager = new FileManager();
    }

    public void createUser() {
        try {
            // Validaciones básicas
            if (getUsername().isEmpty() || getEmail().isEmpty() || getCredential() == null) {
                throw new IllegalArgumentException("Todos los campos son obligatorios");
            }

            // Verificar si el usuario ya existe
            User existingUser = leerUsuario(getEmail());
            if (existingUser != null) {
                throw new IllegalStateException("El usuario ya existe");
            }

            // Guardar en archivo
            String userData = getUsername() + "," + getEmail() + "," + getCredential().getPassword();
            fileManager.guardarUsuario(userData);
            System.out.println("Usuario guardado en archivo exitosamente");

        } catch (IOException e) {
            System.err.println("Error al guardar usuario en archivo: " + e.getMessage());
            throw new RuntimeException("Error al crear usuario", e);
        }
    }

    public void registerUser(String username, String email, String pass) {
        try {
            // Validaciones básicas
            if (username == null || username.isEmpty() ||
                email == null || email.isEmpty() ||
                pass == null || pass.isEmpty()) {
                throw new IllegalArgumentException("Todos los campos son obligatorios");
            }

            // Crear nuevo usuario
            recordUser newUser = new recordUser(username, email, pass);

            // Guardar en archivo
            newUser.createUser();

            // Guardar en caché
            UserCacheManager cacheManager = UserCacheManager.getInstance();
            cacheManager.addUser(newUser);

            System.out.println("Usuario registrado exitosamente");

        } catch (Exception e) {
            System.err.println("Error al registrar usuario: " + e.getMessage());
            throw new RuntimeException("Error en el registro: " + e.getMessage());
        }
    }

    public User leerUsuario(String email) {
        try (BufferedReader reader = new BufferedReader(new FileReader(FileManager.FILE_NAME))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 3 && partes[1].equals(email)) {
                    return new recordUser(partes[0], partes[1], partes[2]);
                }
            }
        } catch (IOException e) {
            System.err.println("Error leyendo usuario: " + e.getMessage());
        }
        return null;
    }
}