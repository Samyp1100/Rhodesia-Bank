package com.proyecto.rhodesiabank.controller;

    import com.proyecto.rhodesiabank.core.Credential;
    import com.proyecto.rhodesiabank.filemanager.FileManager;
    import javafx.event.ActionEvent;
    import javafx.fxml.FXML;
    import javafx.fxml.FXMLLoader;
    import javafx.scene.Node;
    import javafx.scene.Parent;
    import javafx.scene.Scene;
    import javafx.scene.control.Alert;
    import javafx.scene.control.PasswordField;
    import javafx.scene.control.TextField;
    import javafx.stage.Stage;
    import java.io.IOException;
    import java.net.URL;
    import java.util.List;

    public class LogInController {
        @FXML
        private TextField emailField;
        @FXML
        private PasswordField passwordField;

        public boolean iniciarSesion(String email, String password) throws Exception {
            if (email.isEmpty()) {
                throw new Exception("El correo electrónico es requerido");
            }
            if (password.isEmpty()) {
                throw new Exception("La contraseña es requerida");
            }

            FileManager fileManager = new FileManager();
            List<String> usuarios = fileManager.leerUsuarios();
            Credential credential = new Credential(password);

            for (String linea : usuarios) {
                String[] datos = linea.split(",");
                if (datos.length >= 3 && datos[1].equals(email) && datos[2].equals(credential.getPassword())) {
                    return true;
                }
            }
            throw new Exception("Usuario no encontrado");
        }

        @FXML
        private void onLoginClick(ActionEvent event) {
            try {
                String email = emailField.getText();
                String password = passwordField.getText();

                if (iniciarSesion(email, password)) {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/proyecto/rhodesiabank/register.fxml"));
                    Parent root = loader.load();
                    Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                    Scene scene = new Scene(root);
                    stage.setScene(scene);
                    stage.show();
                }
            } catch (Exception e) {
                mostrarError(e.getMessage());
                e.printStackTrace();
            }
        }


        @FXML
        private void onRegistroClick(ActionEvent event) {
            try {
                URL registerUrl = getClass().getResource("/com/proyecto/rhodesiabank/register.fxml");
                FXMLLoader loader = new FXMLLoader(registerUrl);
                Parent root = loader.load();

                Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                Scene scene = new Scene(root);
                stage.setScene(scene);
                stage.show();
            } catch (Exception e) {
                mostrarError("Error al cargar la vista de registro: " + e.getMessage());
            }
        }

        private void mostrarError(String mensaje) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText(mensaje);
            alert.showAndWait();
        }
    }