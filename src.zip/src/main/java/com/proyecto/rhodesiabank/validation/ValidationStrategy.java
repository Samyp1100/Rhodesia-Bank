package com.proyecto.rhodesiabank.validation;

public interface ValidationStrategy {
    boolean validate(String value);
}