package com.proyecto.rhodesiabank.validation;

import com.proyecto.rhodesiabank.core.User;

import java.util.List;

public class ValidatorRegistro {
    private final RecordValidations recordValidations;
    private final List<User> usuarios;  // Lista de usuarios registrados

    public ValidatorRegistro(List<User> usuarios) {
        this.recordValidations = new RecordValidations();
        this.usuarios = usuarios;
    }

    public void validarUsuarioExistente(String email) throws Exception {
        for (User user : usuarios) {
            if (user.getEmail().equals(email)) {
                throw new Exception("El correo electrónico ya está registrado");
            }
        }
    }

    public void validarDatosRegistro(String nombre, String email, String password) throws Exception {
        if (!recordValidations.validarNombre(nombre)) {
            throw new Exception("El nombre debe tener al menos 2 caracteres");
        }

        if (!recordValidations.validarEmail(email)) {
            throw new Exception("El formato del correo electrónico no es válido");
        }

        if (!recordValidations.validarPassword(password)) {
            throw new Exception("La contraseña debe tener al menos 6 caracteres");
        }

        validarUsuarioExistente(email);
    }
}