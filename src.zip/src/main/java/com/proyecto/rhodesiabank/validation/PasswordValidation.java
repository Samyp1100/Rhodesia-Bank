package com.proyecto.rhodesiabank.validation;

public class PasswordValidation implements ValidationStrategy {
    @Override
    public boolean validate(String value) {
        return value != null && value.length() >= 6;
    }
}