package com.proyecto.rhodesiabank.controller;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

import static org.junit.jupiter.api.Assertions.*;

class RegistroControllerTest {

    private RegistroController registroController;

    @BeforeEach
    void setUp() {
        registroController = new RegistroController();
    }

    @Test
    @DisplayName("Registro exitoso con datos válidos")
    void registroExitoso() {
        assertDoesNotThrow(() ->
            registroController.registrarUsuario("Juan Pérez", "juan@mail.com", "123456")
        );
    }

    @Test
    @DisplayName("Falla al registrar con nombre inválido")
    void registroFallaNombreInvalido() {
        Exception exception = assertThrows(Exception.class, () ->
            registroController.registrarUsuario("J", "juan@mail.com", "123456")
        );
        assertTrue(exception.getMessage().contains("nombre"));
    }

    @Test
    @DisplayName("Falla al registrar con email inválido")
    void registroFallaEmailInvalido() {
        Exception exception = assertThrows(Exception.class, () ->
            registroController.registrarUsuario("Juan Pérez", "invalidmail", "123456")
        );
        assertTrue(exception.getMessage().contains("correo"));
    }

    @Test
    @DisplayName("Falla al registrar con contraseña inválida")
    void registroFallaPasswordInvalida() {
        Exception exception = assertThrows(Exception.class, () ->
            registroController.registrarUsuario("Juan Pérez", "juan@mail.com", "123")
        );
        assertTrue(exception.getMessage().contains("contraseña"));
    }

    @Test
    @DisplayName("Falla al registrar con formato de email incorrecto")
    void registroFallaFormatoEmailIncorrecto() {
        Exception exception = assertThrows(Exception.class, () ->
                registroController.registrarUsuario("Juan Pérez", "correo@invalido.", "123456")
        );
        assertTrue(exception.getMessage().contains("formato"));
    }


}