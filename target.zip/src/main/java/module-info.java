module com.proyecto.rhodesiabank {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires net.synedra.validatorfx;
    requires org.kordamp.ikonli.javafx;
    requires org.kordamp.bootstrapfx.core;
    requires eu.hansolo.tilesfx;
    requires com.almasb.fxgl.all;
    requires annotations;

    opens com.proyecto.rhodesiabank to javafx.fxml;
    exports com.proyecto.rhodesiabank;
    exports com.proyecto.rhodesiabank.core;
    opens com.proyecto.rhodesiabank.core to javafx.fxml;
    exports com.proyecto.rhodesiabank.validation;
    opens com.proyecto.rhodesiabank.validation to javafx.fxml;
    exports com.proyecto.rhodesiabank.controller;
    opens com.proyecto.rhodesiabank.controller to javafx.fxml;
    exports com.proyecto.rhodesiabank.application;
    opens com.proyecto.rhodesiabank.application to javafx.fxml;
    exports com.proyecto.rhodesiabank.filemanager;
    opens com.proyecto.rhodesiabank.filemanager to javafx.fxml;
}