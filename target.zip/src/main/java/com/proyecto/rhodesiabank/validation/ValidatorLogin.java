package com.proyecto.rhodesiabank.validation;

import com.proyecto.rhodesiabank.core.User;

public class ValidatorLogin {

    public void validarDatosLogin(String email, String password) throws Exception {
        if (email == null || email.trim().isEmpty()) {
            throw new Exception("El correo electrónico es requerido");
        }

        if (password == null || password.trim().isEmpty()) {
            throw new Exception("La contraseña es requerida");
        }
    }

    public void validarCredenciales(User user, String password) throws Exception {
        if (user == null) {
            throw new Exception("Usuario no encontrado");
        }

        if (!user.getCredential().validatePassword(password)) {
            throw new Exception("Contraseña incorrecta");
        }
    }
}
