package com.proyecto.rhodesiabank.validation;

public class RecordValidations {
    private final ValidationStrategy nombreValidation = new NombreValidation();
    private final ValidationStrategy emailValidation = new EmailValidation();
    private final ValidationStrategy passwordValidation = new PasswordValidation();

    public boolean validarNombre(String nombre) {
        return nombreValidation.validate(nombre);
    }

    public boolean validarEmail(String email) {
        return emailValidation.validate(email);
    }

    public boolean validarPassword(String pass) {
        return passwordValidation.validate(pass);
    }
}