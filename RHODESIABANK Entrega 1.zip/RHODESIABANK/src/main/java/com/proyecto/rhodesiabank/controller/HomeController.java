package com.proyecto.rhodesiabank.controller;

import com.proyecto.rhodesiabank.core.User;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.stage.Stage;

import java.io.IOException;

public class HomeController {
    @FXML
    private VBox mainContainer;
    @FXML
    private Label welcomeLabel;
    @FXML
    private Label balanceLabel;
    @FXML
    private Button btnTransfer;
    @FXML
    private Button btnPayments;
    @FXML
    private Button btnStatement;
    @FXML
    private Button btnProfile;
    @FXML
    private Button btnLogout;



    private User currentUser;

    // Método necesario para recibir el usuario
    public void setUser(User user) {
        this.currentUser = user;
        if (welcomeLabel != null) {
            welcomeLabel.setText("¡Bienvenido/a, " + user.getNombre() + "!");
        }
        if (balanceLabel != null) {
            balanceLabel.setText("Saldo disponible: $" + String.format("%.2f", user.getBalance()));
        }
    }

    @FXML
    public void initialize() {
        System.out.println("Inicializando HomeController...");

        // Si los elementos están definidos en FXML, no necesitamos crearlos aquí
        if (welcomeLabel != null) {
            welcomeLabel.setFont(Font.font("System", FontWeight.BOLD, 24));
            welcomeLabel.setTextFill(Color.web("#1a237e"));
        }

        if (balanceLabel != null) {
            balanceLabel.setText("Saldo disponible: $1,000.00");
            balanceLabel.setFont(Font.font("System", FontWeight.BOLD, 28));
            balanceLabel.setTextFill(Color.web("#2e7d32"));
        }

        // Configurar estilos de botones si existen
        setupButtonStyles();
    }

    private void setupButtonStyles() {
        if (btnTransfer != null) {
            styleButton(btnTransfer, "#1976d2");
        }
        if (btnPayments != null) {
            styleButton(btnPayments, "#1976d2");
        }
        if (btnStatement != null) {
            styleButton(btnStatement, "#1976d2");
        }
        if (btnProfile != null) {
            styleButton(btnProfile, "#1976d2");
        }
        if (btnLogout != null) {
            styleButton(btnLogout, "#d32f2f");
        }
    }

    private void styleButton(Button button, String color) {
        button.setPrefSize(200, 80);
        button.setFont(Font.font("System", FontWeight.BOLD, 14));
        button.setTextFill(Color.WHITE);
        button.setBackground(new Background(new BackgroundFill(
                Color.web(color), new CornerRadii(5), Insets.EMPTY)));

        button.setOnMouseEntered(e -> button.setOpacity(0.9));
        button.setOnMouseExited(e -> button.setOpacity(1.0));
    }

    public void setUserName(String nombre) {
        if (welcomeLabel != null) {
            welcomeLabel.setText("¡Bienvenido/a, " + nombre + "!");
            System.out.println("Nombre de usuario configurado: " + nombre);
        } else {
            System.err.println("welcomeLabel es null - No se pudo configurar el nombre");
        }
    }

    @FXML
    private void onLogoutClick(ActionEvent event) {
        try {
            System.out.println("Cerrando sesión...");
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/proyecto/rhodesiabank/login.fxml"));
            Parent root = loader.load();

            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Rhodesia Bank - Login");
            stage.show();

        } catch (Exception e) {
            System.err.println("Error al cerrar sesión: " + e.getMessage());
            showError("Error al cerrar sesión: " + e.getMessage());
        }
    }

    @FXML
    private void onTransferClick(ActionEvent event) {
        showInfo("Funcionalidad de transferencias próximamente");
    }

    @FXML
    private void onPaymentsClick(ActionEvent event) {
        showInfo("Funcionalidad de pagos próximamente");
    }

    @FXML
    private void onProfileClick(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/proyecto/rhodesiabank/profile.fxml"));
            Parent root = loader.load();

            ProfileController profileController = loader.getController();
            profileController.setUser(currentUser);  // Usar setUser en lugar de initData

            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showError("Error al cargar el perfil: " + e.getMessage());
        }
    }

    @FXML
    private void onStatementClick(ActionEvent event) {
        try {
            System.out.println("Intentando cargar estado de cuenta...");
            String fxmlPath = "/com/proyecto/rhodesiabank/AccountStatement.fxml";
            System.out.println("Ruta FXML: " + fxmlPath);

            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            if (loader.getLocation() == null) {
                throw new IOException("No se pudo encontrar el archivo FXML en: " + fxmlPath);
            }

            Parent root = loader.load();
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Rhodesia Bank - Estado de Cuenta");
            stage.show();

        } catch (IOException e) {
            System.err.println("Error al cargar FXML: " + e.getMessage());
            e.printStackTrace();
            showError("No se pudo cargar la vista de estado de cuenta.");
        }
    }



    private void showInfo(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Información");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}