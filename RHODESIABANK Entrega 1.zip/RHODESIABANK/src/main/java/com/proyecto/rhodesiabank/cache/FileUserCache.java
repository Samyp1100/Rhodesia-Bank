package com.proyecto.rhodesiabank.cache;

import com.proyecto.rhodesiabank.core.Credential;
import com.proyecto.rhodesiabank.core.User;
import com.proyecto.rhodesiabank.core.record.recordUser;
import com.proyecto.rhodesiabank.storage.FileManager;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FileUserCache implements UserCache {
    private final FileManager fileManager;

    public FileUserCache(FileManager fileManager) {
        this.fileManager = fileManager;
    }

    private List<User> convertirLineasAUsuarios(List<String> lineas) {
        List<User> usuarios = new ArrayList<>();
        for (String linea : lineas) {
            if (linea != null && !linea.trim().isEmpty()) {
                String[] datos = linea.trim().split(",");
                if (datos.length == 3) {
                    Credential credential = new Credential();
                    credential.setHashedPassword(datos[2].trim());

                    usuarios.add(new User.UserBuilder()
                            .nombre(datos[0].trim())
                            .email(datos[1].trim())
                            .credential(credential)
                            .build());
                }
            }
        }
        return usuarios;
    }

    @Override
    public void addUser(User user) {
        try {
            // Verificar PRIMERO si el usuario ya existe
            if (existeUsuario(user.getEmail())) {
                throw new RuntimeException("El usuario con el email " + user.getEmail() + " ya existe");
            }

            // Crear el record con los datos del usuario
            recordUser record = new recordUser(
                    user.getNombre().trim(),
                    user.getEmail().trim(),
                    user.getCredential().getPassword().trim()  // Este ya es el hash
            );

            // Guardar en el archivo
            fileManager.guardarUsuario(record.toString());

            System.out.println("Usuario guardado en archivo: " + record.toString());

        } catch (IOException e) {
            throw new RuntimeException("Error al guardar el usuario: " + e.getMessage());
        }
    }

    @Override
    public boolean validateCredentials(String email, String password) {
        try {
            User user = getUser(email.trim());
            if (user == null) {
                System.out.println("Usuario no encontrado: " + email);
                return false;
            }

            // Usar el método validatePassword de la clase Credential
            boolean isValid = user.getCredential().validatePassword(password);

            System.out.println("Validando credenciales para: " + email);
            System.out.println("Contraseña ingresada: " + password);
            System.out.println("Hash almacenado: " + user.getCredential().getPassword());
            System.out.println("Hash de contraseña ingresada: " + user.getCredential().hashPassword(password));
            System.out.println("Validación exitosa: " + isValid);

            return isValid;

        } catch (Exception e) {
            System.out.println("Error en validación: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean existeUsuario(String email) {
        try {
            List<String> lineas = fileManager.leerUsuarios();
            boolean existe = lineas.stream()
                    .filter(linea -> linea != null && !linea.trim().isEmpty())
                    .map(linea -> linea.trim().split(","))
                    .anyMatch(datos -> datos.length == 3
                            && datos[1].trim().equalsIgnoreCase(email.trim()));

            System.out.println("Verificando si existe usuario: " + email + " - Resultado: " + existe);
            return existe;

        } catch (IOException e) {
            System.out.println("Error al verificar usuario existente: " + e.getMessage());
            return false;
        }
    }

    @Override
    public User getUser(String email) {
        try {
            List<String> lineas = fileManager.leerUsuarios();
            return lineas.stream()
                    .filter(linea -> linea != null && !linea.trim().isEmpty())
                    .map(linea -> linea.trim().split(","))
                    .filter(datos -> datos.length == 3 && datos[1].trim().equalsIgnoreCase(email.trim()))
                    .findFirst()
                    .map(datos -> {
                        Credential credential = new Credential();
                        credential.setHashedPassword(datos[2].trim());
                        return new User.UserBuilder()
                                .nombre(datos[0].trim())
                                .email(datos[1].trim())
                                .credential(credential)
                                .build();
                    })
                    .orElse(null);
        } catch (IOException e) {
            System.out.println("Error al obtener usuario: " + e.getMessage());
            return null;
        }
    }

    @Override
    public List<User> getUsers() {
        try {
            List<String> lineas = fileManager.leerUsuarios();
            return convertirLineasAUsuarios(lineas);
        } catch (IOException e) {
            System.out.println("Error al obtener usuarios: " + e.getMessage());
            return new ArrayList<>();
        }
    }
}