package com.proyecto.rhodesiabank.validation;

    import com.proyecto.rhodesiabank.core.Credential;
    import com.proyecto.rhodesiabank.core.User;
    import java.util.List;

    public class ValidatorLogin {
        private final RecordValidations recordValidations;
        private final List<User> usuarios;

        public ValidatorLogin(List<User> usuarios) {
            this.recordValidations = new RecordValidations();
            this.usuarios = usuarios;
        }

        public User validarDatosLogin(String email, String password) throws Exception {
            if (!recordValidations.validarEmail(email)) {
                throw new Exception(recordValidations.getEmailErrorMessage());
            }

            if (!recordValidations.validarPassword(password)) {
                throw new Exception(recordValidations.getPasswordErrorMessage());
            }

            return autenticarUsuario(email, password);
        }

        private User autenticarUsuario(String email, String password) throws Exception {
            for (User user : usuarios) {
                if (user.getEmail().equals(email)) {
                    // Crear credencial con la contraseña ingresada
                    Credential inputCredential = new Credential();
                    inputCredential.setPassword(password);

                    // Comparar directamente los hashes
                    boolean isValid = inputCredential.getPassword().equals(user.getCredential().getPassword());
                    System.out.println("Hash ingresado: " + inputCredential.getPassword());
                    System.out.println("Hash archivo: " + user.getCredential().getPassword());

                    if (isValid) {
                        return user;
                    }
                    throw new Exception("Contraseña incorrecta");
                }
            }
            throw new Exception("Usuario no encontrado");
        }
    }