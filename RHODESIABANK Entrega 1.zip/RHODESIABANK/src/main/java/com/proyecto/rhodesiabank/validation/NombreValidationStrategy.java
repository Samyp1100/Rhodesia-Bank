package com.proyecto.rhodesiabank.validation;

public class NombreValidationStrategy implements ValidationStrategy {

    @Override
    public boolean validate(String value) {
        return value != null &&
               value.trim().length() >= 2 &&
               value.trim().length() <= 50 &&
               value.matches("[A-Za-zÁÉÍÓÚáéíóúÑñ ]{2,50}");
    }

    @Override
    public String getErrorMessage() {
        return "El nombre debe tener entre 2 y 50 caracteres y solo puede contener letras y espacios";
    }
}