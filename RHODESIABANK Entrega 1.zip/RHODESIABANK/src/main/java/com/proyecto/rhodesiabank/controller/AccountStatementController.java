package com.proyecto.rhodesiabank.controller;

import com.proyecto.rhodesiabank.application.LogInApplication;
import com.proyecto.rhodesiabank.core.Transaction;
import com.proyecto.rhodesiabank.core.User;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.scene.control.TableCell;

import java.io.IOException;
import java.text.NumberFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AccountStatementController {
    @FXML
    private Label balanceLabel;
    @FXML
    private TableView<Transaction> transactionsTable;
    @FXML
    private TableColumn<Transaction, LocalDateTime> dateColumn;
    @FXML
    private TableColumn<Transaction, String> typeColumn;
    @FXML
    private TableColumn<Transaction, String> descriptionColumn;
    @FXML
    private TableColumn<Transaction, Double> amountColumn;

    private User currentUser;
    private final NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance();

    @FXML
    public void initialize() {
        // Configurar columnas
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        typeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
        descriptionColumn.setCellValueFactory(new PropertyValueFactory<>("description"));
        amountColumn.setCellValueFactory(new PropertyValueFactory<>("amount"));

        // Formatear fecha
        dateColumn.setCellFactory(column -> new TableCell<>() {
            @Override
            protected void updateItem(LocalDateTime date, boolean empty) {
                super.updateItem(date, empty);
                if (empty || date == null) {
                    setText(null);
                } else {
                    setText(date.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")));
                }
            }
        });

        // Formatear monto
        amountColumn.setCellFactory(column -> new TableCell<>() {
            @Override
            protected void updateItem(Double amount, boolean empty) {
                super.updateItem(amount, empty);
                if (empty || amount == null) {
                    setText(null);
                } else {
                    setText(currencyFormatter.format(amount));
                }
            }
        });
    }

    public void setUser(User user) {
        this.currentUser = user;
        // Actualizar la interfaz con los datos del usuario
        if (balanceLabel != null) {
            balanceLabel.setText("Saldo disponible: $" + String.format("%.2f", user.getBalance()));
        }

        // Cargar transacciones del usuario
        loadUserTransactions();
    }

    private void loadUserTransactions() {
        if (currentUser != null && transactionsTable != null) {
            List<Transaction> transactions = currentUser.getTransactions();
            transactionsTable.setItems(FXCollections.observableArrayList(transactions));
        }
    }

    @FXML
    private void onBackClick(ActionEvent event) {
        try {
            Parent root = FXMLLoader.load(getClass().getResource("/com/proyecto/rhodesiabank/home.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void showError(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}