package com.proyecto.rhodesiabank.validation;

public class PasswordValidationStrategy implements ValidationStrategy {
    @Override
    public boolean validate(String password) {
        // Validación del formato
        return password != null && password.length() >= 6;
    }

    public boolean validateLogin(String inputPassword, String storedPassword) {
        // Validación para el login
        return inputPassword != null &&
                storedPassword != null &&
                inputPassword.equals(storedPassword);
    }

    @Override
    public String getErrorMessage() {
        return "La contraseña debe tener al menos 6 caracteres";
    }
}