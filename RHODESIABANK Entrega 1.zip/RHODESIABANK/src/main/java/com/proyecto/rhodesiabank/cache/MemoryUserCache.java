package com.proyecto.rhodesiabank.cache;

import com.proyecto.rhodesiabank.core.User;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MemoryUserCache implements UserCache {
    private final Map<String, User> cache = new HashMap<>();

   @Override
   public void addUser(User user) {
       if (user == null) {
           throw new IllegalArgumentException("El usuario no puede ser null");
       }
       if (user.getEmail() == null) {
           throw new IllegalArgumentException("El email del usuario no puede ser null");
       }
       if (existeUsuario(user.getEmail())) {
           throw new IllegalStateException("El usuario ya existe");
       }
       cache.put(user.getEmail(), user);
   }

    @Override
    public User getUser(String email) {
        return cache.get(email);
    }

    @Override
    public boolean existeUsuario(String email) {
        return cache.containsKey(email);
    }

    @Override
    public List<User> getUsers() {
        return new ArrayList<>(cache.values());
    }

    @Override
    public boolean validateCredentials(String email, String password) {
        User user = cache.get(email);
        return user != null && user.getPassword().equals(password);
    }
}