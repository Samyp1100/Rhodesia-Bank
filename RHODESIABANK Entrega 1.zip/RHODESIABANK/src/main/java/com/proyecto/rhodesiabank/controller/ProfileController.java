package com.proyecto.rhodesiabank.controller;

import com.proyecto.rhodesiabank.core.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

public class ProfileController {
    @FXML
    private Label nameLabel;
    @FXML
    private Label emailLabel;
    @FXML
    private Label phoneLabel;
    @FXML
    private Label balanceLabel;
    @FXML
    private TextField nameField;
    @FXML
    private TextField phoneField;
    @FXML
    private PasswordField currentPasswordField;
    @FXML
    private PasswordField newPasswordField;
    @FXML
    private PasswordField confirmPasswordField;
    @FXML
    private Button btnUpdateProfile;
    @FXML
    private Button btnChangePassword;
    @FXML
    private Button btnBack;

    private User currentUser;

    @FXML
    public void initialize() {
        System.out.println("Inicializando ProfileController...");
    }

    public void setUser(User user) {
        this.currentUser = user;
        loadUserData();
    }

    private void loadUserData() {
        if (currentUser != null) {
            // Mostrar información del usuario
            if (nameLabel != null) {
                nameLabel.setText(currentUser.getNombre());
            }
            if (emailLabel != null) {
                emailLabel.setText(currentUser.getEmail());
            }
            if (phoneLabel != null) {
                phoneLabel.setText(currentUser.getTelefono() != null ? currentUser.getTelefono() : "No especificado");
            }
            if (balanceLabel != null) {
                balanceLabel.setText("$" + String.format("%.2f", currentUser.getBalance()));
            }

            // Prellenar campos editables
            if (nameField != null) {
                nameField.setText(currentUser.getNombre());
            }
            if (phoneField != null) {
                phoneField.setText(currentUser.getTelefono() != null ? currentUser.getTelefono() : "");
            }
        }
    }

    @FXML
    private void onUpdateProfileClick(ActionEvent event) {
        try {
            String newName = nameField.getText().trim();
            String newPhone = phoneField.getText().trim();

            if (newName.isEmpty()) {
                showError("El nombre no puede estar vacío");
                return;
            }

            // Aquí normalmente actualizarías la información en la base de datos
            // Por ahora, solo mostramos un mensaje de éxito
            showInfo("Perfil actualizado correctamente");

            // Actualizar las etiquetas con la nueva información
            nameLabel.setText(newName);
            phoneLabel.setText(newPhone.isEmpty() ? "No especificado" : newPhone);

        } catch (Exception e) {
            showError("Error al actualizar el perfil: " + e.getMessage());
        }
    }

    @FXML
    private void onChangePasswordClick(ActionEvent event) {
        try {
            String currentPassword = currentPasswordField.getText().trim();
            String newPassword = newPasswordField.getText().trim();
            String confirmPassword = confirmPasswordField.getText().trim();

            if (currentPassword.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
                showError("Todos los campos de contraseña son obligatorios");
                return;
            }

            if (!newPassword.equals(confirmPassword)) {
                showError("Las contraseñas nuevas no coinciden");
                return;
            }

            if (newPassword.length() < 6) {
                showError("La nueva contraseña debe tener al menos 6 caracteres");
                return;
            }

            // Verificar contraseña actual
            if (!currentUser.getCredential().validatePassword(currentPassword)) {
                showError("La contraseña actual es incorrecta");
                return;
            }

            // Aquí normalmente actualizarías la contraseña en la base de datos
            showInfo("Contraseña cambiada correctamente");

            // Limpiar campos
            currentPasswordField.clear();
            newPasswordField.clear();
            confirmPasswordField.clear();

        } catch (Exception e) {
            showError("Error al cambiar la contraseña: " + e.getMessage());
        }
    }

    @FXML
    private void onBackClick(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/proyecto/rhodesiabank/home.fxml"));
            Parent root = loader.load();

            HomeController controller = loader.getController();
            if (controller != null && currentUser != null) {
                controller.setUser(currentUser);
            }

            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Rhodesia Bank - Home");
            stage.show();

        } catch (Exception e) {
            System.err.println("Error al volver: " + e.getMessage());
            showError("Error al volver a la página principal: " + e.getMessage());
        }
    }

    private void showInfo(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Información");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}