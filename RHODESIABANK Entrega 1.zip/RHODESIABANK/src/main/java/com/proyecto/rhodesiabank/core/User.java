package com.proyecto.rhodesiabank.core;

import java.util.ArrayList;
import java.util.List;

public class User {
    private String nombre;
    private String email;
    private String telefono;
    private Credential credential;
    private double balance;
    private List<Transaction> transactions;

    private User(UserBuilder builder) {
        this.nombre = builder.nombre;
        this.email = builder.email;
        this.telefono = builder.telefono;
        this.credential = builder.credential;
        this.balance = builder.balance;
        this.transactions = new ArrayList<>();
    }

    // Getters
    public String getNombre() {
        return nombre;
    }

    public String getEmail() {
        return email;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getPassword() {
        return credential.getPassword();
    }

    public Credential getCredential() {
        return credential;
    }

    public double getBalance() {
        return balance;
    }

    public List<Transaction> getTransactions() {
        return new ArrayList<>(transactions); // Retorna una copia para mantener el encapsulamiento
    }

    public void addTransaction(Transaction transaction) {
        transactions.add(transaction);
        updateBalance(transaction);
    }

    private void updateBalance(Transaction transaction) {
        switch (transaction.getType()) {
            case DEPOSIT:
                this.balance += transaction.getAmount();
                break;
            case WITHDRAWAL:
                this.balance -= transaction.getAmount();
                break;
            case TRANSFER_SENT:
                this.balance -= transaction.getAmount();
                break;
            case TRANSFER_RECEIVED:
                this.balance += transaction.getAmount();
                break;
        }
    }

    public static class UserBuilder {
        private String nombre;
        private String email;
        private String telefono;
        private Credential credential;
        private double balance = 0.0;

        public UserBuilder() {
        }

        public UserBuilder nombre(String nombre) {
            this.nombre = nombre;
            return this;
        }

        public UserBuilder email(String email) {
            this.email = email;
            return this;
        }

        /*public UserBuilder telefono(String telefono) {
            // Validar que el teléfono tenga exactamente 10 dígitos
            if (telefono == null || !telefono.matches("\\d{10}")) {
                throw new IllegalArgumentException("El teléfono debe tener exactamente 10 dígitos");
            }
            this.telefono = telefono;
            return this;
        }*/


        public UserBuilder password(String password) {
            this.credential = new Credential(password);
            return this;
        }

        public UserBuilder credential(Credential credential) {
            this.credential = credential;
            return this;
        }

        public UserBuilder balance(double balance) {
            this.balance = balance;
            return this;
        }

        public User build() {
            if (nombre == null || nombre.isEmpty()) {
                throw new IllegalStateException("El nombre es requerido");
            }
            if (email == null || email.isEmpty()) {
                throw new IllegalStateException("El email es requerido");
            }
            if (credential == null) {
                throw new IllegalStateException("La contraseña es requerida");
            }
            return new User(this);
        }
    }
}