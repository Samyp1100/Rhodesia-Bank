package com.proyecto.rhodesiabank.validation;

public class EmailValidationStrategy implements ValidationStrategy {
    @Override
    public boolean validate(String email) {
        String regex = "^[A-Za-z0-9+_.-]+@(.+)$";
        return email != null && email.matches(regex);
    }

    @Override
    public String getErrorMessage() {
        return "El formato del correo electrónico no es válido";
    }
}

