package com.proyecto.rhodesiabank.controller;

import com.proyecto.rhodesiabank.cache.UserCache;
import com.proyecto.rhodesiabank.cache.UserCacheFactory;
import com.proyecto.rhodesiabank.core.User;
import com.proyecto.rhodesiabank.storage.FileManager;
import com.proyecto.rhodesiabank.validation.PasswordValidationStrategy;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

public class LogInController {
    @FXML
    private TextField emailField;
    @FXML
    private PasswordField passwordField;

    private final UserCache userCache;

    public LogInController() {
        FileManager fileManager = new FileManager("usuarios.txt");
        this.userCache = UserCacheFactory.createCache(fileManager);
    }

    public boolean iniciarSesion(String email, String password) throws Exception {
        if (email == null || email.trim().isEmpty()) {
            throw new Exception("El correo electrónico es requerido");
        }
        if (password == null || password.trim().isEmpty()) {
            throw new Exception("La contraseña es requerida");
        }

        // Verificar si el usuario existe
        User user = userCache.getUser(email.trim());
        if (user == null) {
            throw new Exception("Usuario no encontrado");
        }

        // Validar credenciales usando el método del cache
        boolean isValid = userCache.validateCredentials(email.trim(), password.trim());

        if (!isValid) {
            throw new Exception("Contraseña incorrecta");
        }

        return true;
    }

    private void loginExitoso(User user, ActionEvent event) throws IOException {
        try {
            // Cargar la vista de home
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/proyecto/rhodesiabank/home.fxml"));
            Parent root = loader.load();

            // Obtener el controlador y configurar el nombre del usuario
            HomeController homeController = loader.getController();
            if (homeController != null) {
                homeController.setUserName(user.getNombre());
            }

            // Cambiar la escena
            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.setTitle("Rhodesia Bank - Home");
            stage.show();

            System.out.println("Login exitoso - Redirigiendo a Home para usuario: " + user.getNombre());

        } catch (IOException e) {
            System.err.println("Error al cargar la vista de home: " + e.getMessage());
            throw e;
        }
    }

    @FXML
    private void onLoginClick(ActionEvent event) {
        try {
            String email = emailField.getText().trim();
            String password = passwordField.getText().trim();

            System.out.println("Intentando login para: " + email);

            if (iniciarSesion(email, password)) {
                User user = userCache.getUser(email);
                if (user != null) {
                    System.out.println("Login exitoso para: " + user.getNombre());
                    loginExitoso(user, event);
                } else {
                    mostrarError("Error al obtener información del usuario");
                }
            }
        } catch (Exception e) {
            System.err.println("Error en login: " + e.getMessage());
            mostrarError(e.getMessage());
        }
    }

    @FXML
    private void onRegistroClick(ActionEvent event) {
        try {
            URL registerUrl = getClass().getResource("/com/proyecto/rhodesiabank/register.fxml");
            FXMLLoader loader = new FXMLLoader(registerUrl);
            Parent root = loader.load();

            Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            mostrarError("Error al cargar la vista de registro: " + e.getMessage());
        }
    }

    private void mostrarError(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}