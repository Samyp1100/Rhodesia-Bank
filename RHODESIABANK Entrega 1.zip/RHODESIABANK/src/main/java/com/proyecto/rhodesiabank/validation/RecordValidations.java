package com.proyecto.rhodesiabank.validation;

        public class RecordValidations {
            private final ValidationStrategy nombreValidation;
            private final ValidationStrategy emailValidation;
            private final ValidationStrategy passwordValidation;

            public RecordValidations() {
                this.nombreValidation = new NombreValidationStrategy();
                this.emailValidation = new EmailValidationStrategy();
                this.passwordValidation = new PasswordValidationStrategy();
            }

            public boolean validarNombre(String nombre) {
                return nombreValidation.validate(nombre);
            }

            public boolean validarEmail(String email) {
                return emailValidation.validate(email);
            }

            public boolean validarPassword(String pass) {
                return passwordValidation.validate(pass);
            }

            public String getNombreErrorMessage() {
                return nombreValidation.getErrorMessage();
            }

            public String getEmailErrorMessage() {
                return emailValidation.getErrorMessage();
            }

            public String getPasswordErrorMessage() {
                return passwordValidation.getErrorMessage();
            }
        }