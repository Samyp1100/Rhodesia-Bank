package com.proyecto.rhodesiabank.core;

import java.time.LocalDateTime;

public class Transaction {
    private String id;
    private double amount;
    private String description;
    private LocalDateTime date;
    private TransactionType type;
    private String fromUser;
    private String toUser;

    public enum TransactionType {
        DEPOSIT,
        WITHDRAWAL,
        TRANSFER_SENT,
        TRANSFER_RECEIVED
    }

    public Transaction(String id, double amount, String description, TransactionType type, String fromUser, String toUser) {
        this.id = id;
        this.amount = amount;
        this.description = description;
        this.date = LocalDateTime.now();
        this.type = type;
        this.fromUser = fromUser;
        this.toUser = toUser;
    }

    // Getters
    public String getId() {
        return id;
    }
    public double getAmount() {
        return amount;
    }
    public String getDescription() {
        return description;
    }
    public LocalDateTime getDate() {
        return date;
    }
    public TransactionType getType() {
        return type;
    }
    public String getFromUser() {
        return fromUser;
    }
    public String getToUser() {
        return toUser;
    }
}
