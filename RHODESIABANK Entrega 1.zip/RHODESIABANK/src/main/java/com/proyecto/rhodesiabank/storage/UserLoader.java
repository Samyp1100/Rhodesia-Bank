package com.proyecto.rhodesiabank.storage;

import com.proyecto.rhodesiabank.core.Credential;
import com.proyecto.rhodesiabank.core.User;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class UserLoader {
    private final FileManager fileManager;

    public UserLoader(FileManager fileManager) {
        this.fileManager = fileManager;
    }

    public List<User> loadUsers() throws IOException {
        List<User> users = new ArrayList<>();
        List<String> lineas = fileManager.leerUsuarios();

        for (String linea : lineas) {
            String[] datos = linea.split(",");
            if (datos.length == 3) {
                // Creamos la credencial directamente con el hash del archivo
                Credential credential = new Credential();
                credential.setHashedPassword(datos[2]); // Usar el método nuevo que no vuelve a hashear

                // Construimos el usuario usando la credencial
                User user = new User.UserBuilder()
                        .nombre(datos[0])
                        .email(datos[1])
                        .credential(credential) // Usar la credencial en lugar de password
                        .build();
                users.add(user);
            }
        }
        return users;
    }
}
