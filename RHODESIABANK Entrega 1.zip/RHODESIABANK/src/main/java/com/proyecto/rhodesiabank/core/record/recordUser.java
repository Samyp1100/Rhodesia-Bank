package com.proyecto.rhodesiabank.core.record;

public record recordUser(String nombre, String email, String password) {
    @Override
    public String toString() {
        return String.format("%s,%s,%s",
                nombre.trim(),
                email.trim(),
                password.trim());
    }
}