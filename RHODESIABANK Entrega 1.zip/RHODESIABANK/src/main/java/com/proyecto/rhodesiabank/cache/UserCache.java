package com.proyecto.rhodesiabank.cache;

import com.proyecto.rhodesiabank.core.User;

import java.util.List;

public interface UserCache {
    void addUser(User user);
    User getUser(String email);
    boolean existeUsuario(String email);
    List<User> getUsers();
    boolean validateCredentials(String email, String password);
}