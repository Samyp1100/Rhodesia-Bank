package com.proyecto.rhodesiabank.application;

import com.proyecto.rhodesiabank.controller.RegistroController;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class RegistroApplication extends Application {

  private final RegistroController registroController = new RegistroController();

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Registro de Usuario");

        // Contenedor principal
        VBox mainContainer = new VBox(20);
        mainContainer.setPadding(new Insets(30));
        mainContainer.setAlignment(Pos.CENTER);
        mainContainer.setStyle("-fx-background-color: #f0f2f5;");

        // Título
        Text titulo = new Text("Crear Nueva Cuenta");
        titulo.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

        // Campos de entrada con íconos
        TextField nombreField = createStyledTextField("Nombre completo");
        TextField emailField = createStyledTextField("Correo electrónico");
        PasswordField passField = createStyledPasswordField("Contraseña");
        TextField telefonoField = createStyledTextField("Teléfono");


        // Botón de registro
        Button registrarButton = new Button("Registrar");
        registrarButton.setStyle("""
            -fx-background-color: #1a73e8;
            -fx-text-fill: white;
            -fx-font-size: 14px;
            -fx-padding: 10 20;
            -fx-background-radius: 5;
            -fx-cursor: hand;
            """);
        registrarButton.setPrefWidth(200);

        // Label para mensajes
        Label mensajeLabel = new Label();
        mensajeLabel.setWrapText(true);
        mensajeLabel.setMaxWidth(300);

        // Manejo de eventos
        registrarButton.setOnAction(e -> {
            try {
                    registroController.registrarUsuario(
                    nombreField.getText(),
                    emailField.getText(),
                    passField.getText(),
                    telefonoField.getText()
                    );
                mensajeLabel.setStyle("-fx-text-fill: green;");
                mensajeLabel.setText("¡Registro exitoso!");
                limpiarCampos(nombreField, emailField, passField);
            } catch (Exception ex) {
                mensajeLabel.setStyle("-fx-text-fill: red;");
                mensajeLabel.setText("Error: " + ex.getMessage());
            }
        });

        mainContainer.getChildren().addAll(
            titulo,
            nombreField,
            emailField,
            passField,
            registrarButton,
            mensajeLabel
        );

        Scene scene = new Scene(mainContainer, 400, 500);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private TextField createStyledTextField(String prompt) {
        TextField field = new TextField();
        field.setPromptText(prompt);
        field.setPrefHeight(40);
        field.setMaxWidth(300);
        field.setStyle("""
            -fx-background-radius: 5;
            -fx-border-radius: 5;
            -fx-border-color: #ddd;
            -fx-border-width: 1;
            -fx-padding: 5 10;
            """);
        return field;
    }

    private PasswordField createStyledPasswordField(String prompt) {
        PasswordField field = new PasswordField();
        field.setPromptText(prompt);
        field.setPrefHeight(40);
        field.setMaxWidth(300);
        field.setStyle("""
            -fx-background-radius: 5;
            -fx-border-radius: 5;
            -fx-border-color: #ddd;
            -fx-border-width: 1;
            -fx-padding: 5 10;
            """);
        return field;
    }

    private void limpiarCampos(TextField... campos) {
        for (TextField campo : campos) {
            campo.clear();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}