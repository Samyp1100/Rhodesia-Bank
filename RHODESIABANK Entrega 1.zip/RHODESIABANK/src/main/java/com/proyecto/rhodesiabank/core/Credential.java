package com.proyecto.rhodesiabank.core;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class Credential {
    private String hashedPassword;

    public Credential(String pass) {
        this.hashedPassword = hashPassword(pass);
    }

    public Credential() {
        // Constructor vacío
    }

    public String getPassword() {
        return hashedPassword;
    }

    public void setPassword(String pass) {
        this.hashedPassword = hashPassword(pass);
    }

    // Método nuevo para establecer el hash directamente
    public void setHashedPassword(String hashedPassword) {
        this.hashedPassword = hashedPassword;
    }

    public String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error al encriptar la contraseña", e);
        }
    }

    public boolean validatePassword(String inputPassword) {
        if (inputPassword == null) {
            return false;
        }
        String hashedInput = hashPassword(inputPassword);
        return this.hashedPassword.equals(hashedInput);
    }
}