package com.proyecto.rhodesiabank.controller;

import com.proyecto.rhodesiabank.cache.UserCache;
import com.proyecto.rhodesiabank.cache.UserCacheFactory;
import com.proyecto.rhodesiabank.core.Credential;
import com.proyecto.rhodesiabank.core.record.recordUser;
import com.proyecto.rhodesiabank.storage.FileManager;
import com.proyecto.rhodesiabank.core.User;
import com.proyecto.rhodesiabank.validation.ValidatorRegistro;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import java.io.IOException;
import javafx.stage.Stage;
import java.net.URL;

public class RegistroController {
    private final FileManager fileManager;
    private final ValidatorRegistro validator;
    private final UserCache userCache;

    @FXML private TextField nombreField;
    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;
    @FXML private PasswordField confirmPasswordField;
    @FXML private TextField telefonoField;
    @FXML private Button btnRegistrar;
    @FXML private Button btnReturn;

    public RegistroController() {
        this.fileManager = new FileManager("usuarios.txt");
        this.userCache = UserCacheFactory.createCache(fileManager);
        this.validator = new ValidatorRegistro(userCache.getUsers());
    }

    public void registrarUsuario(String nombre, String email, String password, String telefono) throws Exception {
        // Verificar si el usuario ya existe ANTES de validar otros datos
        if (userCache.existeUsuario(email)) {
            throw new Exception("El correo electrónico ya está registrado");
        }

        validator.validarDatosRegistro(nombre, email, password, telefono);
        // Validar datos de registro

        try {
            // Crear credencial con la contraseña en texto plano (se hasheará automáticamente)
            Credential credential = new Credential(password);

            // Crear usuario usando el Builder con la credencial ya creada
            User nuevoUsuario = new User.UserBuilder()
                    .nombre(nombre.trim())
                    .email(email.trim())
                    .credential(credential)  // Usar la credencial directamente
                    .build();

            // Agregar usuario al cache (esto también lo guarda en el archivo)
            userCache.addUser(nuevoUsuario);

            System.out.println("Usuario registrado exitosamente:");
            System.out.println("Email: " + email);
            System.out.println("Hash guardado: " + credential.getPassword());

        } catch (Exception e) {
            throw new Exception("Error al guardar usuario: " + e.getMessage());
        }
    }

    @FXML
    private void onRegistrarClick(ActionEvent event) {
        try {
            String nombre = nombreField.getText().trim();
            String email = emailField.getText().trim();
            String password = passwordField.getText().trim();
            String telefono = telefonoField.getText().trim();
            String confirmPassword = confirmPasswordField.getText().trim();

            if (nombre.isEmpty() || email.isEmpty() || password.isEmpty()) {
                throw new Exception("Todos los campos son obligatorios");
            }

            if (!password.equals(confirmPassword)) {
                throw new Exception("Las contraseñas no coinciden");
            }

            registrarUsuario(nombre, email, password, telefono);

            mostrarAlertaExito();
            redirigirALogin(event);

        } catch (Exception e) {
            mostrarAlertaError(e.getMessage());
        }
    }

    //private void registrarUsuario(String nombre, String email, String password, String telefono) {}

    private void mostrarAlertaExito() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Registro Exitoso");
        alert.setHeaderText(null);
        alert.setContentText("Usuario registrado correctamente");
        alert.showAndWait();
    }

    private void mostrarAlertaError(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText("Error: " + mensaje);
        alert.showAndWait();
    }

    private void redirigirALogin(ActionEvent event) throws IOException {
        URL loginUrl = getClass().getResource("/com/proyecto/rhodesiabank/login.fxml");
        FXMLLoader loader = new FXMLLoader(loginUrl);
        Parent root = loader.load();
        Scene scene = ((Node) event.getSource()).getScene();
        Stage stage = (Stage) scene.getWindow();
        scene.setRoot(root);
    }

    @FXML
    private void onVolverClick(ActionEvent event) {
        try {
            redirigirALogin(event);
        } catch (IOException e) {
            System.out.println("Error al volver al login: " + e.getMessage());
        }
    }
}