package com.proyecto.rhodesiabank.cache;

import com.proyecto.rhodesiabank.storage.FileManager;

public class UserCacheFactory {
    public static UserCache createCache(FileManager fileManager) {
        try {
            return new FileUserCache(fileManager);
        } catch (RuntimeException e) {
            throw new RuntimeException("No se pudo inicializar el cache de usuarios desde el archivo", e);
        }
    }
}
