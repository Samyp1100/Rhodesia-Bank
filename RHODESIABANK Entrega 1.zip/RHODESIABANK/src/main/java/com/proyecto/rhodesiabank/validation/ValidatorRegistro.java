package com.proyecto.rhodesiabank.validation;

            import com.proyecto.rhodesiabank.core.User;

            import java.util.List;

            public class ValidatorRegistro {
                private final List<User> usuariosExistentes;

                public ValidatorRegistro(List<User> usuariosExistentes) {
                    this.usuariosExistentes = usuariosExistentes;
                }

                public void validarDatosRegistro(String string, String s, String nombre, String email, String telefono) throws Exception {

                }

                public void validarDatosRegistro(String nombreField, String emailField, String passwordField, String telefonoField) {
                }
            }