module com.proyecto.rhodesiabank {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.desktop;

    opens com.proyecto.rhodesiabank to javafx.fxml;
    exports com.proyecto.rhodesiabank;
    exports com.proyecto.rhodesiabank.core;
    opens com.proyecto.rhodesiabank.core to javafx.fxml;
    exports com.proyecto.rhodesiabank.validation;
    opens com.proyecto.rhodesiabank.validation to javafx.fxml;
    exports com.proyecto.rhodesiabank.controller;
    opens com.proyecto.rhodesiabank.controller to javafx.fxml;
    exports com.proyecto.rhodesiabank.application;
    opens com.proyecto.rhodesiabank.application to javafx.fxml;
    exports com.proyecto.rhodesiabank.storage;
    opens com.proyecto.rhodesiabank.storage to javafx.fxml;
}