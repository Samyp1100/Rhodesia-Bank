package com.proyecto.rhodesiabank.controller;

import static org.junit.jupiter.api.Assertions.*;

class LogInControllerTest {

    private LogInController loginController;

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
        loginController = new LogInController();
    }

    @org.junit.jupiter.api.Test
    void iniciarSesionDatosVacios() {
        Exception exception = assertThrows(Exception.class, () ->
            loginController.iniciarSesion("", ""));
        assertEquals("El correo electrónico es requerido", exception.getMessage());
    }

    @org.junit.jupiter.api.Test
    void iniciarSesionSoloEmail() {
        Exception exception = assertThrows(Exception.class, () ->
            loginController.iniciarSesion("test@test.com", ""));
        assertEquals("La contraseña es requerida", exception.getMessage());
    }

    @org.junit.jupiter.api.Test
    void iniciarSesionUsuarioNoExiste() {
        Exception exception = assertThrows(Exception.class, () ->
            loginController.iniciarSesion("noexiste@test.com", "password123"));
        assertEquals("Usuario no encontrado", exception.getMessage());
    }

    @org.junit.jupiter.api.Test
    void iniciarSesionExitoso() throws Exception {
        // Credenciales de un usuario que sabemos que existe
        String email = "marina@gmail.com";
        String password = "123456";

        // Intenta iniciar sesión
        boolean resultado = loginController.iniciarSesion(email, password);

        // Verifica que el inicio de sesión fue exitoso
        assertTrue(resultado, "El inicio de sesión debería ser exitoso con credenciales válidas");
    }
}