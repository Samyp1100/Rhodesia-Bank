package com.proyecto.rhodesiabank.validation;

public class NombreValidation implements ValidationStrategy {
    @Override
    public boolean validate(String value) {
        return value != null && value.matches("[A-Za-zÁÉÍÓÚáéíóúÑñ ]{2,50}");
    }
}