package com.proyecto.rhodesiabank.filemanager;

    import com.proyecto.rhodesiabank.core.Credential;
    import com.proyecto.rhodesiabank.core.User;

    import java.io.IOException;
    import java.util.ArrayList;
    import java.util.HashMap;
    import java.util.List;
    import java.util.Map;


    public class UserCacheManager {
        private static UserCacheManager instancia;
        private final Map<String, User> cache = new HashMap<>();
        private final FileManager fileManager;

        private UserCacheManager() {
            this.fileManager = new FileManager();
            loadCache();
        }

        public static UserCacheManager getInstance() {
            if (instancia == null) {
                instancia = new UserCacheManager();
            }
            return instancia;
        }

        private void loadCache() {
            try {
                List<String> lineas = fileManager.leerUsuarios();
                for (String linea : lineas) {
                    String[] datos = linea.split(",");
                    if (datos.length == 3) {
                        User user = new User(datos[0], datos[1], new Credential(datos[2]));
                        cache.put(datos[1], user);
                    }
                }
            } catch (IOException e) {
                System.err.println("Error al cargar el cache: " + e.getMessage());
            }
        }

        public boolean existeUsuario(String email) {
            return cache.containsKey(email);
        }

        public User getUser(String email) {
            return cache.get(email);
        }

        public List<User> getUsers() {
            return new ArrayList<>(cache.values());
        }

        public void addUser(User nuevoUsuario) {
            if (nuevoUsuario != null && nuevoUsuario.getEmail() != null && !existeUsuario(nuevoUsuario.getEmail())) {
                cache.put(nuevoUsuario.getEmail(), nuevoUsuario);
            }
        }
    }