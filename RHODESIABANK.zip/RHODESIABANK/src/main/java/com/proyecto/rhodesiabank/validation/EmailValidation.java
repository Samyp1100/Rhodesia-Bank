package com.proyecto.rhodesiabank.validation;

public class EmailValidation implements ValidationStrategy {
    @Override
    public boolean validate(String value) {
        return value != null && value.matches("^[\\w.-]+@[\\w.-]+\\.[A-Za-z]{2,}$");
    }
}