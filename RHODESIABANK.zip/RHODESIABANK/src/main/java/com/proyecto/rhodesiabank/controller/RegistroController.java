package com.proyecto.rhodesiabank.controller;

import com.proyecto.rhodesiabank.core.Credential;
import com.proyecto.rhodesiabank.filemanager.FileManager;
import com.proyecto.rhodesiabank.filemanager.UserCacheManager;
import com.proyecto.rhodesiabank.core.User;
import com.proyecto.rhodesiabank.validation.ValidatorRegistro;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.Button;         // Para el botón
import javafx.event.ActionEvent;            // Para el evento del botón
import javafx.fxml.FXMLLoader;             // Para cargar la vista
import javafx.scene.Parent;                // Para el root de la escena
import javafx.scene.Scene;                 // Para manejar la escena
import java.io.IOException;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import java.net.URL;

public class RegistroController {
    private final FileManager fileManager;
    private final ValidatorRegistro validator;
    private final UserCacheManager userCache;
    @FXML
    private TextField nombreField;
    @FXML
    private TextField emailField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private PasswordField confirmPasswordField;
    @FXML
    private Button btnRegistrar;
    @FXML
    private Button btnReturn;

    public RegistroController() {
        this.fileManager = new FileManager();
        this.userCache = UserCacheManager.getInstance();
        this.validator = new ValidatorRegistro(userCache.getUsers());
    }

    public void registrarUsuario(String nombre, String email, String pass) throws Exception {
        // Verificación explícita de usuario existente
        if (userCache.existeUsuario(email)) {
            throw new Exception("El correo electrónico ya está registrado");
        }

        // Validamos el resto de los datos
        validator.validarDatosRegistro(nombre, email, pass);

        try {
            // Si pasa las validaciones, creamos el usuario
            Credential credencial = new Credential(pass);
            User nuevoUsuario = new User(nombre, email, credencial);

            // Guardamos en cache
            userCache.addUser(nuevoUsuario);

            // Guardamos en archivo
            String userData = nombre + "," + email + "," + credencial.getPassword();
            fileManager.guardarUsuario(userData);

        } catch (IOException e) {
            throw new Exception("Error al guardar usuario: " + e.getMessage());
        }
    }

    @FXML
    private void onRegistrarClick(ActionEvent event) {
        try {
            String nombre = nombreField.getText();
            String email = emailField.getText();
            String password = passwordField.getText();
            String confirmPassword = confirmPasswordField.getText();

            // Validaciones
            if (nombre.isEmpty() || email.isEmpty() || password.isEmpty()) {
                throw new Exception("Todos los campos son obligatorios");
            }

            if (!password.equals(confirmPassword)) {
                throw new Exception("Las contraseñas no coinciden");
            }

            // Registrar usuario
            registrarUsuario(nombre, email, password);

            // Mostrar mensaje de éxito
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Registro Exitoso");
            alert.setHeaderText(null);
            alert.setContentText("Usuario registrado correctamente");
            alert.showAndWait();

            // Cargar la vista de login usando URL absoluta
            URL loginUrl = getClass().getResource("/com/proyecto/rhodesiabank/login.fxml");
            FXMLLoader loader = new FXMLLoader(loginUrl);
            Parent root = loader.load();

            // Obtener la escena actual
            Scene scene = ((Node) event.getSource()).getScene();
            Stage stage = (Stage) scene.getWindow();

            // Cambiar a la escena de login
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();

        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Error: " + e.getMessage());
            alert.showAndWait();
        }
    }
    @FXML
    private void onVolverClick(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/proyecto/rhodesiabank/login.fxml"));
            Parent root = loader.load();
            Scene scene = ((Node) event.getSource()).getScene();
            scene.setRoot(root);
        } catch (IOException e) {
            System.out.println("Error al volver al login: " + e.getMessage());
        }
    }
}

